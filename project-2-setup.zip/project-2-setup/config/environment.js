const port = process.env.NODE_ENV || 3000;

module.exports = { port };